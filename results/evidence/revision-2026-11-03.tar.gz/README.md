# SLO-Aware Chaos Engineering for Cloud-Native Applications

Cloud Computing Course CEP by Muhammad Awwab Khan (SE-23051) and Muhammad Abyaz Khalid (SE-23053), NED University of Engineering and Technology.

## Current state
Implementation prototype is available: count-based dual-SLO accountant, matched-cohort
attribution, four policies, conservative admission/stopping, short/long burn windows,
cooldown, checkpointing, local HTTP benchmark, restricted Istio adapter, independent
watchdog, k6 orchestration, checksummed evidence, descriptive analysis, and empirical
cost summaries. Local and disposable-cluster safety checks and engineering pilots have
been run. These are not final comparative research results. Existing Introduction and
Literature Review are preserved. Novelty is provisional; see docs/NOVELTY.md.

Deadline: **16 November 2026**. No course rubric supplied.

Quick start (from this project directory):

```sh
uv sync --frozen
uv run pytest -q
uv run cc-cep smoke --output results/raw/my-local-check
uv run cc-cep simulate --output results/raw/my-model-run
uv run cc-cep analyze results/raw/my-model-run
```

Use a new output directory for each execution. The committed `uv.lock` pins Python
packages; project-local CLI versions and publisher/binary checksums are recorded in
`deploy/tools.lock.json`. Tools live under ignored `.tools/bin`.

- [Implementation/runbook](docs/IMPLEMENTATION.md)
- [Research/novelty audit](docs/NOVELTY.md)
- [Pilot/evaluation protocol](experiments/PROTOCOL.md)
- [Verification evidence](results/curated/)

The dedicated local cluster is `kind-cc-cep`; its kubeconfig is ignored and local.
No cloud resources or spending are used.

## Review corrections and full study

The interval-Wilson consumption defect is fixed in `realized-cumulative-v2`: zero bad
requests consume zero budget. Conditional background credit uses a separate sequential
calculation; the default grants no credit without the declared model. Cleanup exhaustion
sets a sticky failed flag. A later successful removal cannot mark that execution successful.

The original development archive is now included under `results/evidence/` with an
external SHA-256 file. Verify its 169 internal manifests without third-party packages:

```sh
python scripts/reproduce_evidence.py --archive results/evidence/implementation-2026-11-03.tar.gz --destination results/tmp/original-evidence-new
```

See [accounting details](docs/ACCOUNTING-V2.md), [full-duration frozen protocol](experiments/FULL-STUDY.md),
[demonstration](docs/DEMONSTRATION.md), and [long-run operation](docs/FULL-STUDY-RUNBOOK.md).
The user explicitly retained 120/300/120-second phases. The main 90 trials need roughly
14 hours; 20 background ablations add roughly three hours. Statistical code is ready;
completed cluster inference and final report conclusions remain pending collection.

Native Windows unit-test collection no longer imports `fcntl` unconditionally. Install
the locked dependencies with `uv sync --frozen` before testing. A Windows/Linux CI workflow
is provided, but Windows execution has not been performed in this session. Cluster setup,
crash/recovery supervision and the current binary installer still require Linux/WSL.

The compiled interim report, editable slide deck and labelled recorded-trace demo are
under ignored `output/`. They distinguish measured engineering checks from pending
comparative results. The full study's final rendering remains review-required.

## Overleaf
Upload the project source and choose **cas-dc-template.tex** as the Main document in Overleaf settings. Use **pdfLaTeX** and BibTeX with an available current TeX Live release. The manuscript uses Elsevier's two-column CAS class.

Required local files:
- cas-dc-template.tex: manuscript.
- cas-dc.cls and cas-common.sty: original vendor layout files.
- cas-model2-names.bst: bundled bibliography style.
- cas-refs.bib: existing research references.
- thumbnails/cas-email.jpeg: used by the author email footer.

The original vendor README and manifest are retained for provenance; the manifest describes the upstream distribution, including removed examples. Sample PDFs, alternative single-column templates, sample figures, and vendor documentation sources have been removed.

After upload, use Recompile from scratch and inspect the log, bibliography, author notes, and wide comparison table. Local cleanup does not synchronize an existing Overleaf project automatically. No Overleaf account or remote project is connected in this workspace.

## Local PDF build
Install a TeX distribution with latexmk, then run:

~~~powershell
latexmk -pdf -interaction=nonstopmode -halt-on-error cas-dc-template.tex
~~~

Without latexmk, run pdfLaTeX, BibTeX, pdfLaTeX, pdfLaTeX on the manuscript basename.
Do not commit generated PDF/build files. The vendor .cls/.sty/.bst files retain their upstream licenses.

## Project work
- [Agent guidance](AGENTS.md)
- [Complete CEP plan](docs/CEP-PLAN.md)
- [Decisions and assumptions](docs/DECISIONS.md)

The deadline is 16 November 2026. No course rubric or brief has been supplied. The local Docker VM has approximately 8 GiB of RAM; host memory was freed for cluster provisioning. Final comparison parameters remain provisional pending pilots.
