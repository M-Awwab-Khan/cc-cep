from cc_cep.statistics import paired_interval


def test_exact_constant_paired_difference():
    result = paired_interval({1: 2, 2: 2, 3: 2, 4: 2, 5: 2}, [1, 2, 3, 4, 5])
    assert result["complete"]
    assert result["mean_difference"] == result["ci_low"] == result["ci_high"] == 2


def test_missing_failed_block_cannot_disappear_from_inference():
    result = paired_interval({1: 1, 2: 2}, [1, 2, 3, 4, 5])
    assert not result["complete"]
    assert result["missing_blocks"] == [3, 4, 5]
    assert result["ci_low"] is None
