import tarfile

from cc_cep import evidence


def test_source_bundle_excludes_runtime_credentials_and_tools(tmp_path, monkeypatch):
    root = tmp_path / "source"
    root.mkdir()
    for name in ["pyproject.toml", "uv.lock", "AGENTS.md"]:
        (root / name).write_text("public")
    (root / "kubeconfig.local").write_text("secret")
    (root / ".env").write_text("secret")
    (root / "src").mkdir()
    (root / "src/example.py").write_text("public")
    output = tmp_path / "bundle"
    output.mkdir()
    monkeypatch.setattr(evidence, "ROOT", root)
    evidence.snapshot_source(output)
    with tarfile.open(output / "source.tar.gz") as archive:
        names = archive.getnames()
    assert "src/example.py" in names
    assert "kubeconfig.local" not in names and ".env" not in names
