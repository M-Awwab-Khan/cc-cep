# Decisions and assumptions

## Accepted initialization choices
- Preserve the existing manuscript filename to minimize Overleaf main-document disruption.
- Keep the two-column CAS class, original vendor sources, and email icon.
- Use bundled cas-model2-names.bst instead of the absent elsarticle-num-names.bst.
- Initialize Git without making an initial commit or configuring a remote.
- Preserve existing research text and bibliography; indexing, novelty, and verification assertions still require evidence.
- Remove unused template distribution examples and documentation; retain original README and manifest.

## Provisional implementation decisions
- Python controller, Prometheus/Grafana observability, Kubernetes, and k6 load generation.
- Start with a small instrumented microservice application; use Online Boutique for external validity after the core works.
- Request-level Istio delay/abort injection for controllable intensity; Chaos Mesh for later infrastructure fault scenarios.
- Prefer independent, matched experiment/control application stacks for attribution; prove isolation and request labeling in a spike.
- Aim for an eight-week schedule with a four-week minimum-scope fallback.

## Historical initialization inputs (superseded by the implementation decisions below)
Course brief/rubric and required CEP learning outcomes; submission date/page limit; laptop CPU/RAM and Docker/WSL availability; cloud credits/provider and cost ceiling; instructor expectations for novelty, experiments, and permitted references.
At initialization, no deployment or cloud spend had been initiated.


## Implementation decisions — 3 November 2026

- User authorized implementation and installation, supplied a 16 November deadline,
  reported no rubric, and freed RAM for a local cluster. Use the neighboring cc-cep Git
  repository; leave the Terraform lab untouched. No cloud spend.
- Install checksum-verified kind 0.33.0, kubectl 1.36.0, Istioctl 1.31.3, Helm 4.3.1,
  k6 2.3.0 under ignored .tools/bin. Pin package resolution in uv.lock. Use digest-pinned
  Python, kind node, Prometheus and Grafana images. Record actual runtime image IDs.
- Dedicated kind cluster cc-cep, namespace cc-cep, separate control/treatment frontend
  and dependency services. Faults target only the treatment dependency hostname; do not
  depend on downstream propagation of a cohort header. Shared-node interference remains.
- Treat client k6 outcome points as count telemetry, including failed connections and
  timeouts. Server Prometheus histograms support inspection, not latency-budget arithmetic.
- Reserve fixed bad-request allocations. Refuse admission when the declared lag/removal
  reserve cannot fit. Pilot's larger laboratory reservation is explicit in PROTOCOL.md;
  it is not evidence over a real long SLO window.
- Keep signed excess estimates and a clipped Wilson-based enforcement screen separately.
  The screen is not a time-uniform confidence guarantee and creates stopping bias.
- Use monotonic time for durations/exposure and UTC timestamps for evidence. Exposure is
  the API-acknowledged command integral; Envoy propagation introduces measurement error.
- Controller restart never resumes an old fault intensity. Use a target lock, atomic
  checkpoints, cleanup-before-admission, finite leases, and a separate bounded watchdog.
  The lock is host-local; a distributed Kubernetes leader lease remains a future gate.
- First cluster spike exposed a shared-resource optimistic-write race. Keep failed/invalid
  evidence. Move watchdog heartbeat to the safety ConfigMap; it no longer rewrites fault
  routing on each heartbeat. Strengthen expiry checks to reject premature removal.
- Include post-stop client counts in cleanup-tail accounting. Checkpoint state and
  preserve cleanup errors rather than treating a stop command as removal proof.
- Preserve all manuscript text and vendor assets. DOI metadata audit is separate from
  claim verification. No final novelty, statistical advantage, or causal claim yet.


## Review-driven corrections and evaluation — 3 November 2026

- Treat the review as a correction list, not confirmation that the CEP is complete.
- Replace accumulated interval-Wilson charges with realized cumulative debit. Default
  enforcement charges observed treatment bad events; background credit requires the
  declared iid/monotonicity assumptions and sequential lower-bound calculation.
- Preserve cleanup failure as sticky even after recovery. Retain every failed attempt.
- Include the original raw archive and checksum in results/evidence. New evidence has
  source snapshots, baseline snapshots, raw organic labels, pod identity/image inventory,
  full ledger replay and client-count reconciliation.
- User explicitly chose the full experiment durations and confirmed machine availability.
  Freeze 80 core runs, 10 controls and 20 subsequent background/debit-mode ablations;
  120/300/120-second phases, randomized blocks 1001–1005, order seed 20261103.
- Capacity-path calibration selected 48 and 112 RPS from a 160 RPS healthy tested level.
  Preserve the failed rollout probe and failed 320 RPS probe. They are not favorable
  data selections hidden from the archive.
- Use pilot seed 21 and independently measured abort/delay costs before freezing. The
  open-loop percentage divides usable budget by fault-window traffic, not reservation traffic.
- Freeze source in a separate local snapshot and detach the one-off sequential process
  from the interactive command session. Runtime links to kubeconfig/tools are excluded
  from archives. A target lock prevents concurrent fault controllers.
- Use paired block bootstrap intervals and preserve missing/failed blocks explicitly.
  Predeclare full-allocation and usable-guard overshoot separately; never represent
  a large reserve as demonstrated tight control of the full allocation.
- Paper revisions now remove the unverified WOS search/gap claim and prototype promises
  about Online Boutique/Chaos Mesh. Those remain optional future extensions.
- Add native Windows lock support and a pinned-actions CI matrix. No Windows execution
  result is claimed; cluster tooling/supervision still uses Linux/WSL.
- Automatic post-study artifacts remain review-required. Do not label data collection,
  report compilation, or plausible novelty as completion of the entire CEP.

### Native-sidecar admission correction (2026-11-03)

The initial full-study-v2 driver was stopped after readiness admission repeatedly
failed before baseline/load generation: Istio 1.31 uses a native sidecar under
initContainerStatuses, while the new provenance check inspected only regular
containerStatuses. All failed attempts and the stopped status are retained. No
measurement-window outcomes were collected. The corrected inventory includes the
named istio-proxy from either location, excluding the completed istio-init. A
regression test checks both layouts. The queue now halts after any trial exhausts
its single invalid-execution retry, so systematic failures cannot consume the
whole plan. Full-study-v3 freezes the correction; its loads, order, seeds, budgets,
phase durations and statistical design are identical to v2. No frozen v2 code was
changed, and no failed trial was relabelled successful.
