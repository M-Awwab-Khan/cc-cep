# Demonstration

The supplied MP4 replays retained engineering-pilot observations. It is labelled as a
recorded trace, not a live browser/cluster capture. The timing axis uses actual admission
and observation timestamps; no extra measurements are interpolated into the ledgers.

```sh
uv run python scripts/build_demo.py \
  --run results/raw/revision-cost-delay-01 \
  --output output/demo/recorded-controller-trace.mp4
```

For a viva, first show the corrected no-fault run: 2,006 healthy treatment outcomes,
zero consumption and a duration stop. Then show the labelled delay trace and explain
that the short pilot establishes operation, not policy superiority. Explain the
independent watchdog, sticky cleanup-failure status, client-side SLI counts, and the
limitations of background credit. Show the full-study status and paired analysis once
available; do not substitute the earlier simulation matrix for cluster evidence.

A live demonstration requires the disposable test cluster and a fresh safety check.
Run the documented `cc_cep.cluster_smoke` and `cc_cep.live` commands only when the full
study is stopped or completed. The target lock refuses simultaneous controllers.
Emergency stop: create results/tmp/EMERGENCY_STOP, then verify cleanup/readback. Delete
the stop file only when deliberately admitting a subsequent experiment.
